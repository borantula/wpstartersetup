<?php
/**
 * The template for displaying 404 pages (Not Found).
 *
 * @package _s
 */

get_header(); ?>

<div>Sayfa Bulunamadı</div>

<?php get_footer(); ?>