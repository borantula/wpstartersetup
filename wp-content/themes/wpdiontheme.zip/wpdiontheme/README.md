wpdiontheme
===========

A base and stripped theme for especially CMS like use cases
