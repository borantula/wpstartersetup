/* not intended for direct use */

function dionAjaxUrl(event)
{
	return siteAjax.ajaxUrl+'?action='+siteAjax.action+'&amadeus_event='+event;
}